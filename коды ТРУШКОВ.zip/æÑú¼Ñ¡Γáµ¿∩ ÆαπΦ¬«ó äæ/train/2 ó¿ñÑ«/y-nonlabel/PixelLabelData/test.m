for i=1:23
    Im=imread('Label_'+string(i),'png');
    N=label2rgb(Im);
    imwrite(N,'gt'+string(i)+'.png');
end
