% figure
% imshow(Label_1)
% X=Label_1;
% % [x,y]=bwlabel(X);
% N=label2rgb(X);
% figure
% imshow(N)

for i=1:25
    Im=imread('Label_'+string(i),'png');
    N=label2rgb(Im);
    imwrite(N,'gt'+string(i)+'.png')
end
